.. highlight:: rst

MYCOASTLCS summary
====================================

This python module computes the Finite Time Lyapunov exponentes and also extracts the Lagrangian Coherent Structures using the  `ridge detection method: <https://shaddenlab.berkeley.edu/uploads/LCS-tutorial/LCSdef.html for PYLAG/LAGAR Lagrangian output models>`_. 

At the moment, this module support the following features, for PYLAG and LAGAR models:
 
- Computation of FTLE in 2d and 3d cartesian coordinates
- Computation of FTLE in 2d spherical cooordinates.
- Extraction of LCS using FTLE ridge method for 2d FTLE.

The module it also includes the posibility to be used with other lagrangian models. However it requires a netcdf dataset alias dictionary to provided the correspondence from the diferent model ouputs and the variables x,y,z used to compute the FTLE and other Lagrangian measures. To run it right, the advection performed (in order to compute the FTLE) should be done with a grid of initial conditions regularly spaced in 2d and/or 3d.


:Authors: 
	Angel Daniel Garaboa Paz (USC), Vicente Perez Muñuzuri (USC), Ricardo Torres (PMI), James Clark (PMI)


:Version: 0.1 of 2019/01/01 
