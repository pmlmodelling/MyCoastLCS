.. MYCOASTLCSdocumentation master file, created by
   sphinx-quickstart on Mon Mar 25 14:32:55 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

MYCOASTLCS
========================================

Contents:

.. toctree::

	introduction
	FTLEandLCS



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
